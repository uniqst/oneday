<aside id="sidebar" class="col-md-<?php echo get_theme_mod( 'right-sidebar-size', 3 ); ?> rsrc-right" role="complementary" itemscope itemtype="http://schema.org/WPSideBar">
	<?php dynamic_sidebar( 'alpha-store-home-sidebar' ); ?>
</aside>
